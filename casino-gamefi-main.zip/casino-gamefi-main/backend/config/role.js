module.exports = {
    "superadmin": "SUPER_ADMIN",
    "admin": "ADMIN",
    "user": "USER"
};