module.exports.devServer = {
    cluser: "cluster0.eghoy",
    database: "casinogamefi",
    username: "adonis",
    password: "rh6B1zaOqgN8Y5I3"
}