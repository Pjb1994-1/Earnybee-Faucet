module.exports = {
    JWT_SECRET_KEY: "casinogamefi",
    TOKEN_HEADER_KEY: "Authorization"
};